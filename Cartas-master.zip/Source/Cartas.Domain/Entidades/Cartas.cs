﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cartas.Domain.Entidades
{
    public class Cartas
    {

        #region Contrutores
        public Cartas(string nomeDaCrianca, string endereco, int idadeDaCrianca, string textoDaCarta)
        {
            NomeDaCrianca = nomeDaCrianca;
            Endereco = endereco;
            IdadeDaCrianca = idadeDaCrianca;
            TextoDaCarta = textoDaCarta;
        }
        #endregion

        #region Propriedades
        public string NomeDaCrianca { get; private set; }

       
        public string Endereco { get; private set; }

        public int IdadeDaCrianca { get; private set; }
        public string TextoDaCarta { get; private set; }
        #endregion

        #region Funcoes
        public void EscreverCartasNoArquivo(Cartas Cartas) { }
        public void LerCartasNoArquivo() { }
        #endregion
    }
}
