﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cartas.Domain.Entidades;
namespace Cartas.Domain.Interface
{
    public interface ICartasRepository
    {
        Task<IEnumerable<Cartas>> LerCartasDoArquivo();
    }
}
