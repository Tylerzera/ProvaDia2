﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace Revisao_01.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CartasController : ControllerBase
    {


        private readonly string Cartas;

        public CartasController()
        {
            Console.WriteLine(Directory.GetCurrentDirectory());
            Cartas = Path.Combine(Directory.GetCurrentDirectory(), "Data", "Cartas.json");
        }
        private List<CartaDoPapaiNoel> LerCartasDoArquivo()
        {
            if (!System.IO.File.Exists(Cartas))
            {
                return new List<CartaDoPapaiNoel>();
            }

            string json = System.IO.File.ReadAllText(Cartas);
            return JsonConvert.DeserializeObject<List<CartaDoPapaiNoel>>(json);
        }

        private void EscreverCartasNoArquivo(List<CartaDoPapaiNoel> cartas)
        {
            string json = JsonConvert.SerializeObject(cartas);
            System.IO.File.WriteAllText(Cartas, json);
        }

        [HttpGet]
        public ActionResult Get()
        {

            return Ok(LerCartasDoArquivo());

        }

        [HttpPost]

        public IActionResult Post([FromBody] CartaDoPapaiNoel newCarta)
        {

            List<CartaDoPapaiNoel> cartas = LerCartasDoArquivo();

            CartaDoPapaiNoel novaCarta = new CartaDoPapaiNoel()
            {

                NomeDaCrianca = newCarta.NomeDaCrianca,
                Endereco = newCarta.Endereco,
                IdadeDaCrianca = newCarta.IdadeDaCrianca,
                TextoDaCarta = newCarta.TextoDaCarta
            };

            cartas.Add(novaCarta);
            EscreverCartasNoArquivo(cartas);

            return CreatedAtAction(nameof(Get), new { codigo = novaCarta.NomeDaCrianca }, novaCarta);
        }


    }
}
