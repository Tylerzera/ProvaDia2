﻿namespace Application.ViewModels
{
    public class CartaViewModel
    {
        public int Id { get; set; }
        public string NomeDaCrianca { get; set; }
        public string Endereco { get; set; }
        public int IdadeDaCrianca { get; set; }
        public string TextoDaCarta { get; set; }
    }
}
