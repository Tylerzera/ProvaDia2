﻿public interface ICartaService
{
    List<Carta> ListarCartas();
    Carta AdicionarCarta(Carta novaCarta);
}